import { searchVideos } from "./clients/pexel.js";
import { putObject } from "./clients/s3.js";

/**
 * Main scraping logic that fetches videos and uploads them to R2
 * @param {Object} options - Configuration options
 * @param {number} options.videoCount - Number of videos to fetch
 * @param {string} options.query - Search query for videos
 * @param {string} options.bucketName - R2 bucket name
 * @returns {Promise<Object>} Results of the scraping operation
 */
export async function scrapeAndStore(options = {}) {
  const {
    videoCount = 1,
    query = "cat",
    bucketName = "fakeout-videos-dev",
  } = options;

  console.log(`Fetching ${videoCount} videos for query: "${query}"`);
  const videos = await searchVideos({ query, per_page: videoCount });
  console.log(`Found ${videos.length} videos`);

  // Test R2 upload with metadata
  console.log("\n--- Uploading metadata to R2 ---");
  const testData = JSON.stringify({
    message: "Video scrape results",
    timestamp: new Date().toISOString(),
    videoCount: videos.length,
    videos: videos.map((v) => ({
      id: v.id,
      url: v.url,
      duration: v.duration,
      width: v.width,
      height: v.height,
    })),
  });

  const result = await putObject({
    bucketName,
    key: `scrapes/${Date.now()}.json`,
    body: testData,
    contentType: "application/json",
  });

  console.log("✓ Successfully uploaded to R2:");
  console.log(`  Bucket: ${bucketName}`);
  console.log(`  Key: ${result.key}`);
  console.log(`  ETag: ${result.etag}`);

  return {
    videoCount: videos.length,
    videos,
    uploadResult: result,
  };
}

/**
 * AWS Lambda handler function
 * @param {Object} event - Lambda event object
 * @param {Object} context - Lambda context object
 * @returns {Promise<Object>} Lambda response
 */
export async function handler(event, context) {
  console.log("Lambda invoked with event:", JSON.stringify(event, null, 2));

  try {
    // Parse event parameters
    const videoCount = event.videoCount || 1;
    const query = event.query || "cat";
    const bucketName = event.bucketName || "fakeout-videos-dev";

    // Execute scraping
    const result = await scrapeAndStore({ videoCount, query, bucketName });

    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        message: "Successfully scraped and stored videos",
        data: {
          videoCount: result.videoCount,
          uploadKey: result.uploadResult.key,
          uploadETag: result.uploadResult.etag,
        },
      }),
    };
  } catch (error) {
    console.error("Error in Lambda handler:", error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        message: "Failed to scrape and store videos",
        error: error.message,
      }),
    };
  }
}
